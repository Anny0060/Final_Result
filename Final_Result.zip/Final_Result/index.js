const upComingHackathonDataList = [
    {
        companyLogoUrl: "./assets/images/company-1.png",
        companyName: "Company 1",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-1.jpeg",
    },
    {
        companyLogoUrl: "./assets/images/company-2.png",
        companyName: "Company 2",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-2.jpeg",
    },
    {
        companyLogoUrl: "./assets/images/company-3.png",
        companyName: "Company 3",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-3.jpeg",
    },
    {
        companyLogoUrl: "./assets/images/company-4.png",
        companyName: "Company 4",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-4.jpeg",
    },
    {
        companyLogoUrl: "./assets/images/company-5.png",
        companyName: "Company 5",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-5.jpeg",
    },
    {
        companyLogoUrl: "./assets/images/company-6.jpg",
        companyName: "Company 6",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-6.jpg",
    },
    {
        companyLogoUrl: "./assets/images/company-7.jpg",
        companyName: "Company 7",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-7.jpg",
    },
    {
        companyLogoUrl: "./assets/images/company-8.jpg",
        companyName: "Company 8",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-8.jpg",
    },
    {
        companyLogoUrl: "./assets/images/company-9.jpg",
        companyName: "Company 9",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-9.jpg",
    },
    {
        companyLogoUrl: "./assets/images/company-10.jpg",
        companyName: "Company 10",
        prizePool: "1,20,000",
        lastDateToApply: "April 12, 2024",
        tag: ["Resource", "Physics"],
        approxApplicant: "+50 Applicant",
        hackathonImageUrl: "./assets/images/hack-10.jpg",
    },
];

document.addEventListener("DOMContentLoaded", function () {

    // upcoming
    const cardRowDiv = document.getElementById("card-row");
    upComingHackathonDataList.forEach((data) => cardRowDiv.appendChild(createCard(data)));
    const carousel = document.querySelector(".carousel-1");
    const wrapper = document.querySelector(".wrapper");
    enableCarouselDrag(carousel, wrapper);


    // coding
    const cardRowDiv2 = document.getElementById("card-row-2");
    upComingHackathonDataList.forEach((data) => cardRowDiv2.appendChild(createCard(data)));
    const carousel2 = document.querySelector(".carousel-2");
    const wrapper2 = document.querySelector(".wrapper-2");
    enableCarouselDrag(carousel2, wrapper2);
});

function enableCarouselDrag(carousel, wrapper) {
    let isDragging = false,
        startX,
        startScrollLeft,
        timeoutId;

    const dragStart = (e) => {
        isDragging = true;
        carousel.classList.add("dragging");
        startX = e.pageX;
        startScrollLeft = carousel.scrollLeft;
    };

    const dragging = (e) => {
        if (!isDragging) return;

        // Calculate the new scroll position
        const newScrollLeft = startScrollLeft - (e.pageX - startX);

        // Check if the new scroll position exceeds the carousel boundaries
        if (
            newScrollLeft <= 0 ||
            newScrollLeft >= carousel.scrollWidth - carousel.offsetWidth
        ) {
            // If so, prevent further dragging
            isDragging = false;
            return;
        }

        // Otherwise, update the scroll position of the carousel
        carousel.scrollLeft = newScrollLeft;
    };

    const dragStop = () => {
        isDragging = false;
        carousel.classList.remove("dragging");
    };

    // Event listeners
    carousel.addEventListener("mousedown", dragStart);
    carousel.addEventListener("mousemove", dragging);
    document.addEventListener("mouseup", dragStop);
    wrapper.addEventListener("mouseenter", () => clearTimeout(timeoutId));
}


function createCard(upComingHackathonData) {
    // Create a container for the card
    const colDiv = document.createElement("li");
    colDiv.className = "akn-card";

    // Create the card element
    const cardDiv = document.createElement("div");
    cardDiv.className = "card br-15";

    // Create the card body
    const cardBodyDiv = document.createElement("div");
    cardBodyDiv.className = "card-body";

    // Create the d-flex container for the top section
    const dFlexTopDiv = document.createElement("div");
    dFlexTopDiv.className =
        "d-flex justify-content-between align-items-center";

    // Create the company logo container
    const logoContainerDiv = document.createElement("div");
    logoContainerDiv.className =
        "border rounded-circle d-flex align-items-center justify-content-center logo-container";

    // Create the company logo image
    const logoImg = document.createElement("img");
    logoImg.src = upComingHackathonData.companyLogoUrl;
    logoImg.alt = upComingHackathonData.companyName;
    logoImg.className = "img-fluid object-fit-cover w-100 company-logo";
    logoContainerDiv.appendChild(logoImg);

    // Create the company name
    const companyNameDiv = document.createElement("div");
    companyNameDiv.className = "ms-3 fw-bold";
    companyNameDiv.id = "company-name";
    companyNameDiv.textContent = upComingHackathonData.companyName;

    // Create the up arrow icon
    const upIconDiv = document.createElement("div");
    upIconDiv.className =
        "rounded-circle d-flex align-items-center justify-content-center bg-secondary-subtle up-icon";

    // Create the icon element
    const iconI = document.createElement("i");
    iconI.className = "fas fa-arrow-up text-black rotate-45";
    upIconDiv.appendChild(iconI);

    // Append logo container and company name to d-flex container
    const dFlexTopInnerDiv = document.createElement("div");
    dFlexTopInnerDiv.className = "d-flex align-items-center";
    dFlexTopInnerDiv.appendChild(logoContainerDiv);
    dFlexTopInnerDiv.appendChild(companyNameDiv);
    dFlexTopDiv.appendChild(dFlexTopInnerDiv);
    dFlexTopDiv.appendChild(upIconDiv);

    // Create the horizontal rule
    const hr = document.createElement("hr");

    // Create the main text
    const cardTextP = document.createElement("p");
    cardTextP.className = "card-text my-2 fw-bold fs-4";
    cardTextP.innerHTML = "Coding <br> Hackthon";

    // Create the row for prize and date
    const rowDiv1 = document.createElement("div");
    rowDiv1.className = "row";

    const col1 = document.createElement("div");
    col1.className = "col lh-1";
    const prizeSpan = document.createElement("span");
    prizeSpan.className = "fs-82 text-muted";
    prizeSpan.textContent = "1st Prize";
    const amountSpan = document.createElement("span");
    amountSpan.className = "fs-82 light-blue-color";
    amountSpan.id = "amount";
    amountSpan.textContent = `$${upComingHackathonData.prizePool}`;
    col1.appendChild(prizeSpan);
    col1.appendChild(document.createElement("br"));
    col1.appendChild(amountSpan);

    const col2 = document.createElement("div");
    col2.className = "col lh-1 text-end";
    const dateLabelSpan = document.createElement("span");
    dateLabelSpan.className = "fs-82 text-muted";
    dateLabelSpan.textContent = "Last date to apply:";
    const dateSpan = document.createElement("span");
    dateSpan.className = "fs-82";
    dateSpan.id = "date";
    dateSpan.textContent = upComingHackathonData.lastDateToApply;
    col2.appendChild(dateLabelSpan);
    col2.appendChild(document.createElement("br"));
    col2.appendChild(dateSpan);

    rowDiv1.appendChild(col1);
    rowDiv1.appendChild(col2);

    // Create the row for tags and applicants
    const rowDiv2 = document.createElement("div");
    rowDiv2.className = "row mt-3";

    const col3 = document.createElement("div");
    col3.className = "col";

    // Create tags from the array
    upComingHackathonData.tag.forEach((tag) => {
        const badge = document.createElement("span");
        badge.className = "badge rounded-pill text-bg-secondary me-2";
        badge.textContent = tag;
        col3.appendChild(badge);
    });

    const col4 = document.createElement("div");
    col4.className = "col text-end";
    const applicantsSpan = document.createElement("span");
    applicantsSpan.className = "fs-82 text-muted";
    applicantsSpan.textContent = upComingHackathonData.approxApplicant;
    col4.appendChild(applicantsSpan);

    rowDiv2.appendChild(col3);
    rowDiv2.appendChild(col4);

    // Create the row for the image
    const rowDiv3 = document.createElement("div");
    rowDiv3.className = "row mt-3";

    const col5 = document.createElement("div");
    col5.className = "col";
    const upImage = document.createElement("img");
    upImage.src = upComingHackathonData.hackathonImageUrl;
    upImage.className =
        "rounded w-100 object-fit-cover up-image-height";
    col5.appendChild(upImage);

    rowDiv3.appendChild(col5);

    // Append all the elements to the card body
    cardBodyDiv.appendChild(dFlexTopDiv);
    cardBodyDiv.appendChild(hr);
    cardBodyDiv.appendChild(cardTextP);
    cardBodyDiv.appendChild(rowDiv1);
    cardBodyDiv.appendChild(rowDiv2);
    cardBodyDiv.appendChild(rowDiv3);

    // Append card body to the card
    cardDiv.appendChild(cardBodyDiv);

    // Append card to the column
    colDiv.appendChild(cardDiv);

    return colDiv;
}